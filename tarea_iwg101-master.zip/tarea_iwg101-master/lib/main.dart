import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Colors.blue[200],
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CircleAvatar(
                radius: 50.0,
                backgroundImage: AssetImage('images/jinx.png'), //cambio de nombre y archivo
              ),
              Text(
                'Youmi',
                style: TextStyle(
                  fontSize: 40.0,
                  fontFamily: 'Pacifico',
                  color: Colors.red[300], //cambio de color y tipo de letra
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Jugador profesional y Estudiante USM',
                style: TextStyle(
                  fontSize: 22.0,
                  fontFamily: 'Pacifico',
                  color: Colors.purple[300], //cambio de color y tipo de letra
                ),
              ),
              Card(
                margin: EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 25.0,
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.call,
                    color: Colors.orange,
                  ),
                  title: Text(
                    '+56 9 100000000',
                    style: TextStyle(
                      color: Colors.orange, //cambio de color 
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 25.0,
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.email,
                    color: Colors.orange, //cambio de color 
                  ),
                  title: Text(
                    'star_guardian@usm.cl',
                    style: TextStyle(
                      fontFamily: 'Pacifico',
                      color: Colors.orange, //cambio de color y tipo de letra
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 25.0,
                ),
                child: ListTile(
                  leading: Text(
                    '@',
                    style: TextStyle(
                      color: Colors.orange, //cambio de color 
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  title: Text(
                    'Seba',
                    style: TextStyle(
                      fontFamily: 'Pacifico',
                      color: Colors.orange, //cambio de color y tipo de letra
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ),
              Card(
                margin: EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 25.0,
                ),
                child: ListTile(
                  leading: Icon(
                    Icons.directions,
                    color: Colors.orange, //cambio de color
                  ),
                  title: Text(
                    'Chile',
                    style: TextStyle(
                      fontFamily: 'Pacifico',
                      color: Colors.orange, //cambio de color y tipo de letra
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ),
              Card( //Tarjeta agregada con las mismas características pero personalizado
                margin: EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 25.0,
                ),
                child: ListTile(
                  leading: Text(
                    '★',
                    style: TextStyle(
                      color: Colors.orange, //cambio de color 
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  title: Text(
                    'Liga: Grand Master',
                    style: TextStyle(
                      fontFamily: 'Pacifico',
                      color: Colors.orange, //cambio de color y tipo de letra
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
